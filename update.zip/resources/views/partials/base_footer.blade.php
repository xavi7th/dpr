<footer class="main-footer">
  <strong>Copyright &copy; 2018</strong> All rights
  reserved.
</footer>
