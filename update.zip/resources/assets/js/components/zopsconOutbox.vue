<template lang="html">
  <div class="">
    <h1>zopscon outbox</h1>
  </div>
</template>

<script>
export default {
    mounted() {
        console.log('Component hmm.');
    }
}
</script>
