<?php $__env->startSection('title'); ?>
  DPR Staff | Application Review
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagestyles'); ?>
  <style>
    #pt_style b{
      font-size: 20px;
    }
    #pt_style a{
      font-size: 20px;
      color: red;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">

    <?php echo $__env->make('partials.backend_top_nav_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo $__env->make('partials.backend_aside_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          Application Review
          <small>Staff Control panel</small>
        </h1>
      </section>


      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-md-4">
            <div class="box box-primary">
              <div class="box-body box-profile">

                <h3 class="profile-username text-center" style="text-transform: capitalize;"><?php echo e($applicationReview->name_of_gas_plant); ?></h3>

                <p class="text-muted text-center"><?php echo e($applicationReview->application_id); ?></p>

                <ul class="list-group list-group-unbordered">
                  <li class="list-group-item">
                    <b>Application type</b> <a class="pull-right"><?php echo e($applicationReview->application_type); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Sub-category</b> <a class="pull-right"><?php echo e($applicationReview->sub_category); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Plant type</b> <a class="pull-right"><?php echo e($applicationReview->plant_type); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Capacity of tank</b> <a class="pull-right"><?php echo e($applicationReview->capacity_of_tank); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>State</b> <a class="pull-right"><?php echo e($applicationReview->state); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>L.G.A</b> <a class="pull-right"><?php echo e($applicationReview->lga); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Town</b> <a class="pull-right"><?php echo e($applicationReview->town); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Address</b> <a class="pull-right"><?php echo e($applicationReview->address); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Application Date</b> <a class="pull-right"><?php echo e($applicationReview->created_at->diffForHumans()); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Application Status</b>
                    <?php if($reportDocument != null): ?>
                      <div class="box-tools pull-right tools" data-toggle="modal" data-target="#report" style="position: relative; bottom: 5px;">
                        <button type="button" class="btn btn-box-tool"><i class="fa fa-eye" style="font-size: 18px;"></i></button>
                      </div>
                    <?php endif; ?>
                    <a class="pull-right text-red"><?php echo e($applicationStatus->job_application_status); ?></a>
                  </li>

                    <?php if($reportDocument != null): ?>
                      <li class="list-group-item">
                        <form role="form" method="post" action="/up_to_teamlead">
                          <?php echo e(csrf_field()); ?>

                          <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->application_id); ?>">
                          <input type="text" hidden name="sub_category" value="<?php echo e($applicationReview->sub_category); ?>">
                          <input type="text" hidden name="marketer_id" value="<?php echo e($applicationReview->marketer_id); ?>">
                          <input type="text" hidden name="application_type" value="<?php echo e($applicationReview->application_type); ?>">
                          <input type="text" hidden name="id" value="<?php echo e($applicationReview->id); ?>">
                          <input type="text" hidden name="company_id" value="<?php echo e($reportDocument->company_id); ?>">
                          <input type="text" hidden name="staff_id" value="<?php echo e($reportDocument->staff_id); ?>">
                          <input type="text" hidden name="report_url" value="<?php echo e($reportDocument->report_url); ?>">
                          <div class="box-footer">
                            <input type="submit" name="upToTeamlead" value="Send to Team Lead" class="pull-right btn btn-primary">
                          </div>
                        </form>
                      </li>
                    <?php endif; ?>

                  
                </ul>
              </div>
              <!-- /.box-body -->
            </div>
            <?php if($applicationStatus->job_application_status == 'ATC Issued'): ?>
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Upload ATC follow up Document</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form role="form" method="post" action="/stUpload_construction_report" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                  <div class="box-body">
                  <div class="form-group">
                    <label for="exampleInputFile">Construction Document</label>
                    <input type="file" name="reportDocument">
                    <input type="text" hidden name="company_id" value="<?php echo e($applicationReview->company_id); ?>">
                    <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->application_id); ?>">
                    <input type="text" hidden name="staff_id" value="<?php echo e(Auth::user()->staff_id); ?>">
                  </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                  <button type="submit" class="pull-right btn btn-default">Upload
                    <i class="fa fa-upload"></i></button>
                  </div>
                </form>
              </div>
            <?php else: ?>
              <?php if($applicationReview->to_staff == 'true' || $applicationReview->to_staff == 'received'): ?>
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Upload Report</h3>
                  </div>
                  <!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="/stUpload_report" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputFile">Report Document</label>
                      <input type="file" name="reportDocument">
                      <input type="text" hidden name="company_id" value="<?php echo e($applicationReview->company_id); ?>">
                      <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->application_id); ?>">
                      <input type="text" hidden name="staff_id" value="<?php echo e(Auth::user()->staff_id); ?>">
                    </div>
                  </div>
                  <!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="pull-right btn btn-default">Upload
                      <i class="fa fa-upload"></i></button>
                    </div>
                  </form>
                </div>
              <?php endif; ?>
            <?php endif; ?>

            <div class="modal fade" id="report" style="display: none;">
              <div class="modal-dialog" style="width: 1400px;">
                <div class="modal-content" style="background: transparent;">
                  <?php if($reportDocument != null): ?>
                    <img src="/storage/comp_reports/<?php echo e($reportDocument->company_id); ?>/<?php echo e($reportDocument->staff_id); ?>/<?php echo e($reportDocument->application_id); ?>/<?php echo e($reportDocument->report_url); ?>" alt="">
                  <?php endif; ?>
                </div>
              </div>
            </div>

            <div class="box box-primary direct-chat direct-chat-warning">
              <div class="box-header with-border">
                <h3 class="box-title">Report Comments</h3>
                <div class="box-tools pull-right">
                  <span data-toggle="tooltip" title="" class="badge bg-blue" data-original-title="<?php echo e($applicationComments->count()); ?> Comments"><?php echo e($applicationComments->count()); ?></span>
                  <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                </div>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                <!-- Conversations are loaded here -->
                <div class="direct-chat-messages">
                  <!-- Message. Default to the left -->
                  <?php $__currentLoopData = $applicationComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                      <div class="direct-chat-msg">
                        <div class="direct-chat-info clearfix">
                          <span class="direct-chat-name pull-left" style="text-transform: capitalize;"><?php echo e($comment->staff['first_name']); ?> <?php echo e($comment->staff['last_name']); ?> <i class="text-yellow"><b>(<?php echo e($comment->staff['role']); ?>)</b></i></span>
                          <span class="direct-chat-timestamp pull-right"><?php echo e($comment->created_at->diffForHumans()); ?></span>
                        </div>
                        <!-- /.direct-chat-info -->
                        <img class="direct-chat-img" src="/dist/img/user1-128x128.jpg" alt="message user image">
                        <!-- /.direct-chat-img -->
                        <div class="direct-chat-text">
                          <?php echo e($comment->comment); ?>

                        </div>
                        <!-- /.direct-chat-text -->
                      </div>
                      <!-- /.direct-chat-msg -->
                      <br>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <form action="/make_report_comment" method="post">
                  <?php echo e(csrf_field()); ?>

                  <div class="input-group">
                    <input type="text" name="comment" placeholder="Type Message ..." class="form-control" required>
                    <input type="text" name="application_id" hidden value="<?php echo e($applicationReview->application_id); ?>">
                    <span class="input-group-btn">
                      <button type="submit" class="btn btn-primary btn-flat">Make Comment</button>
                    </span>
                  </div>
                </form>
              </div>
              <!-- /.box-footer-->
            </div>

        </div>
        <div class="col-md-8">
          <div class="box box-primary">
            <!-- /.box-header -->
            <div class="box-body">
              <?php if($applicationReview->sub_category == 'Site Suitability Inspection' || $applicationReview->sub_category == 'ATC'): ?>
                <?php echo $__env->make('partials.m_view_application_docs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php elseif($applicationReview->sub_category == 'LTO'): ?>
                <?php echo $__env->make('partials.m_view_application_docs_lto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php elseif($applicationReview->sub_category == 'Renewal'): ?>
                <?php echo $__env->make('partials.m_view_application_docs_lto_renewal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php elseif($applicationReview->sub_category == 'Take Over'): ?>
                <?php echo $__env->make('partials.m_view_application_docs_takeover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php elseif($applicationReview->sub_category == 'Pressure Testing'): ?>
                <?php echo $__env->make('partials.m_view_application_docs_pressure_test', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php endif; ?>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- quick email widget -->
          <div class="box box-info">
            <div class="box-header">
              <i class="fa fa-envelope"></i>

              <h3 class="box-title">Quick Message to Marketer</h3>
              <!-- tools box -->
              <div class="pull-right box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
              </div>
              <!-- /. tools -->
            </div>
            <div class="box-body">
              <form action="#" method="post">
                <div class="form-group">
                  <input type="email" hidden name="emailto" placeholder="Email to:">
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="subject" placeholder="Subject">
                </div>
                <div>
                  <textarea class="textarea" placeholder="Message"
                  style="width: 100%; height: 125px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                </div>
              </form>
            </div>
            <div class="box-footer clearfix">
              <button type="button" class="pull-right btn btn-default" id="sendEmail">Send
                <i class="fa fa-arrow-circle-right"></i></button>
              </div>
            </div>
          </div>
        </div>

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('partials.base_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
  <!-- page script -->
  <script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>