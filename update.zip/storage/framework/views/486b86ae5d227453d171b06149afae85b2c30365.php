<?php $__env->startSection('title'); ?>
  DPR | License to operate Records
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagestyles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">

    <?php echo $__env->make('partials.backend_top_nav_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php if(Auth::user()->role == 'Marketer'): ?>
      <?php echo $__env->make('partials.backend_aside_marketer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Admin'): ?>
      <?php echo $__env->make('partials.backend_aside_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Staff'): ?>
      <?php echo $__env->make('partials.backend_aside_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Team Lead'): ?>
      <?php echo $__env->make('partials.backend_aside_teamlead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Head Gas M&G Lagos'): ?>
      <?php echo $__env->make('partials.backend_aside_headgas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'ADO'): ?>
      <?php echo $__env->make('partials.backend_aside_ado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'ZOPSCON'): ?>
      <?php echo $__env->make('partials.backend_aside_zopscon', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          License to operate Records
        </h1>
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="box">
              <div class="box-header">
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                <table id="example1" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Application ID</th>
                    <th>Name of Gas Plant</th>
                    <th>Application Type</th>
                    <th>Sub-Category</th>
                    <th>Plant Type</th>
                    <th>Application Status</th>
                    <th>Date Issued</th>
                    <th>Expiry Date</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $appDocReviewsLTO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="sorting_1">
                          <?php if(Auth::user()->role == 'Marketer'): ?>
                            <?php if(now()->gte($item->expiry_date)): ?>
                              <a href="/mDocument_review/<?php echo e($item->id); ?>" class="label label-danger" style="font-size: 14px;"><?php echo e($item->application_id); ?></a>
                            <?php elseif(now()->addMonths(3)->gte($item->expiry_date)): ?>
                              <a href="/mDocument_review/<?php echo e($item->id); ?>" class="label label-warning" style="font-size: 14px;"><?php echo e($item->application_id); ?></a>
                            <?php else: ?>
                              
                              <a href="/mDocument_review/<?php echo e($item->id); ?>" class="label label-success" style="font-size: 14px;"><?php echo e($item->application_id); ?></a>
                            <?php endif; ?>
                          <?php else: ?>
                            <?php if(now()->gte($item->expiry_date)): ?>
                              <a href="/document_review/<?php echo e($item->application_id); ?>" class="label label-danger" style="font-size: 14px;"><?php echo e($item->application_id); ?></a>
                            <?php elseif(now()->addMonths(3)->gte($item->expiry_date)): ?>
                              <a href="/document_review/<?php echo e($item->application_id); ?>" class="label label-warning" style="font-size: 14px;"><?php echo e($item->application_id); ?></a>
                            <?php else: ?>
                              
                              <a href="/document_review/<?php echo e($item->application_id); ?>" class="label label-success" style="font-size: 14px;"><?php echo e($item->application_id); ?></a>
                            <?php endif; ?>
                          <?php endif; ?>

                        </td>
                        <td><?php echo e($item->name_of_gas_plant); ?></td>
                        <td><?php echo e($item->application_type); ?></td>
                        <td><?php echo e($item->sub_category); ?></td>
                        <td><?php echo e($item->plant_type); ?></td>
                        <td><?php echo e($item->application_status); ?></td>
                        <td>
                          <?php echo e(Carbon\Carbon::parse($item->date_issued)->toFormattedDateString()); ?>

                        </td>
                        <td>
                          <?php echo e(Carbon\Carbon::parse($item->expiry_date)->toFormattedDateString()); ?>

                        </td>

                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.box-body -->
            </div>

          </div>
          <!-- ./col -->
        </div>

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('partials.base_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>