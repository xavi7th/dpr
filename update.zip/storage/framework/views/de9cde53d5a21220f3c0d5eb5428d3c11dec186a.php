<?php $__env->startSection('title'); ?>
  DPR Administrator | Edit Staffs Records
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagestyles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">

    <?php echo $__env->make('partials.backend_top_nav_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.backend_aside_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          Edit <span style="text-transform: capitalize;"><?php echo e($staffID->first_name); ?>'s</span> Records
          <small>Administrator Control Panel</small>
        </h1>
      </section>

      <!-- Main content -->
      <section class="content">

        <div class="row">
          <div class="col-xs-4">
            <div class="box box-primary">
            <div class="box-body box-profile">

              <h3 class="profile-username text-center" style="text-transform: capitalize;"><?php echo e($staffID->first_name); ?> <?php echo e($staffID->last_name); ?></h3>

              <p class="text-muted text-center"><?php echo e($staffID->role); ?></p>
              <p class="text-muted text-center text-green"><b><?php echo e($staffID->staff_id); ?></b></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Mobile Number</b> <a class="pull-right"><?php echo e($staffID->mobile_number); ?></a>
                </li>
                <li class="list-group-item">
                  <b>Email Address</b> <a class="pull-right"><?php echo e($staffID->email_address); ?></a>
                </li>
                <li class="list-group-item">
                  <b>Date</b> <a class="pull-right"><?php echo e($staffID->created_at->diffForHumans()); ?></a>
                </li>
              </ul>
            </div>
            <!-- /.box-body -->
          </div>
        </div>

        <div class="col-md-4">
          <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Update Staff</h3>
          </div>
          <!-- /.box-header -->
          <!-- form start -->
          <form role="form" method="POST" action="/update_staff_role">
            <?php echo e(csrf_field()); ?>

            <div class="box-body">
              <div class="form-group">
                <label>Staff Role</label>
                <select class="form-control select2" name="role" style="width: 100%;">
                  <option selected="selected" value="nu">Select Role</option>
                  <option value="ZOPSCON">ZOPSCON</option>
                  <option value="ADO">ADO</option>
                  <option value="Head Gas">Head Gas M&G Lagos</option>
                  <option value="Team Lead">Team Lead</option>
                  <option value="Staff">Staff</option>
                  <option value="Admin">Admin</option>
                  <option value="Marketer">Marketer</option>
                </select>
              </div>
              <input type="text" hidden name="SID" value="<?php echo e($staffID->id); ?>">
            <!-- /.box-body -->
            <div class="box-footer">
              <button type="submit" class="btn btn-primary pull-right">Submit</button>
            </div>
            <!-- /.box-footer -->
          </form>
        </div>
        </div>

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('partials.base_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
  <!-- page script -->
  <script>
    $(function () {
      $('#example1').DataTable()
      $('#example2').DataTable({
        'paging'      : true,
        'lengthChange': false,
        'searching'   : false,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
      })
    })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>