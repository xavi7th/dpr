<?php $__env->startSection('title'); ?>
  DPR Marketer | View Application Documents
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagestyles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">

    <?php echo $__env->make('partials.backend_top_nav_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php if(Auth::user()->role == 'Marketer'): ?>
      <?php echo $__env->make('partials.backend_aside_marketer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Admin'): ?>
      <?php echo $__env->make('partials.backend_aside_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Staff'): ?>
      <?php echo $__env->make('partials.backend_aside_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Team Lead'): ?>
      <?php echo $__env->make('partials.backend_aside_teamlead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Head Gas M&G Lagos'): ?>
      <?php echo $__env->make('partials.backend_aside_headgas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'ADO'): ?>
      <?php echo $__env->make('partials.backend_aside_ado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'ZOPSCON'): ?>
      <?php echo $__env->make('partials.backend_aside_zopscon', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          License details
        </h1>
      </section>


      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-md-4">
            <div class="box box-primary">
            <div class="box-body box-profile">

              <h3 class="profile-username text-center"><?php echo e($appDocReviewed->name_of_gas_plant); ?></h3>

              <p class="text-muted text-center"><?php echo e($appDocReviewed->application_id); ?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Application type</b> <a class="pull-right"><?php echo e($appDocReviewed->application_type); ?></a>
                </li>
                <li class="list-group-item">
                  <b>Sub-category</b> <a class="pull-right"><?php echo e($appDocReviewed->sub_category); ?></a>
                </li>
                <li class="list-group-item">
                  <b>Plant type</b> <a class="pull-right"><?php echo e($appDocReviewed->plant_type); ?></a>
                </li>
                <li class="list-group-item">
                  <b>Capacity of tank</b> <a class="pull-right"><?php echo e($appDocReviewed->capacity_of_tank); ?></a>
                </li>
                <li class="list-group-item">
                  <b>State</b> <a class="pull-right"><?php echo e($appDocReviewed->state); ?></a>
                </li>
                <li class="list-group-item">
                  <b>L.G.A</b> <a class="pull-right"><?php echo e($appDocReviewed->lga); ?></a>
                </li>
                <li class="list-group-item">
                  <b>Town</b> <a class="pull-right"><?php echo e($appDocReviewed->town); ?></a>
                </li>
                <li class="list-group-item">
                  <b>Address</b> <a class="pull-right"><?php echo e($appDocReviewed->address); ?></a>
                </li>
                <li class="list-group-item">
                  <b>Date</b> <a class="pull-right"><?php echo e($appDocReviewed->created_at); ?></a>
                </li>
                
                <br>
                
              </ul>
            </div>
            <!-- /.box-body -->
          </div>
          </div>
          <div class="col-md-8">
            <div class="box box-primary">
              <div class="box-header ui-sortable-handle" style="cursor: move;">
                <h3 class="box-title">Application ID: <?php echo e($applicationID->application_id); ?></h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                <?php if($appDocReviewed->sub_category == 'Site Suitability Inspection' || $appDocReviewed->sub_category == 'ATC'): ?>
                  <?php echo $__env->make('partials.m_view_application_docs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($appDocReviewed->sub_category == 'ATC'): ?>
                  <?php echo $__env->make('partials.m_view_application_docs_atc', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($appDocReviewed->sub_category == 'LTO'): ?>
                  <?php echo $__env->make('partials.m_view_application_docs_lto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
              </div>
              <!-- /.box-body -->
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('partials.base_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>