<?php $__env->startSection('title'); ?>
  DPR Marketer | Application Document Records
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagestyles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">

    <?php echo $__env->make('partials.backend_top_nav_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo $__env->make('partials.backend_aside_marketer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          Application Document Records
          <small>Marketer Control panel</small>
        </h1>
      </section>

      <!-- Main content -->
      <section class="content">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-md-3">
            <div class="small-box bg-aqua">
              <div class="inner">
                <h3><?php echo e($appDocReviews->count()); ?></h3>

                <p>Records</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="box">
              <div class="box-header">
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                <table id="example1" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Application ID</th>
                    <th>Name of Gas Plant</th>
                    
                    <th>Sub-Category</th>
                    
                    <th>State</th>
                    <th>lga</th>
                    <th>Status</th>
                    <th>Application Date</th>
                    
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $appDocReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="sorting_1">
                          <?php if($item->application_status == 'Application Pending'
                          || $item->application_status == 'Site Not Suitable'
                          || $item->application_status == 'ATC Not Issued'
                          || $item->application_status == 'LTO Not Issued'
                          || $item->application_status == 'Renewal Declined'
                          || $item->application_status == 'Take Over Not Approved'
                          ): ?>
                            <a class="label label-success" style="font-size: 14px;"><?php echo e($item->application_id); ?></a>
                          <?php else: ?>
                            <a href="/mDocument_review/<?php echo e($item->id); ?>" class="label label-success" style="font-size: 14px;"><?php echo e($item->application_id); ?></a>
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($item->name_of_gas_plant); ?></td>
                        
                        <td><?php echo e($item->sub_category); ?></td>
                        
                        <td><?php echo e($item->state); ?></td>
                        <td><?php echo e($item->lga); ?></td>
                        <td>
                          <?php if($item->application_status == 'Site Not Suitable'
                          || $item->application_status == 'ATC Not Issued'
                          || $item->application_status == 'LTO Not Issued'
                          || $item->application_status == 'Renewal Declined'
                          || $item->application_status == 'Take Over Not Approved'
                          ): ?>
                            <i class="fa fa-close text-red"></i>
                          <?php elseif($item->application_status == 'Site Suitable'
                          || $item->application_status == 'ATC Issued'
                          || $item->application_status == 'LTO Issued'
                          || $item->application_status == 'Renewal Approved'
                          || $item->application_status == 'Take Over Approved'
                          ): ?>
                            <i class="fa fa-check-circle text-green"></i>
                          <?php elseif($item->application_status == 'Application Pending'): ?>
                            <i class="fa fa-send text-blue"></i>
                          <?php else: ?>
                            <a href="/mDocument_edit/<?php echo e($item->id); ?>" class="" style="font-size: 13px;"><i class="fa fa-gears text-black"></i></a>
                          <?php endif; ?>
                        </td>
                        <td><?php echo e(Carbon\Carbon::parse($item->created_at)->toFormattedDateString()); ?></td>
                        
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.box-body -->
            </div>

          </div>
          <!-- ./col -->
        </div>
        <!-- /.row (main row) -->

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('partials.base_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
  <script>
    $(function () {
      $('#example1').DataTable()
      $('#example2').DataTable({
        'paging'      : true,
        'lengthChange': false,
        'searching'   : false,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
      })
    })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>