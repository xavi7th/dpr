<?php $__env->startSection('title'); ?>
  DPR Team Lead | Application Review / Assignment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagestyles'); ?>
  <style>
    #pt_style b{
      font-size: 20px;
    }
    #pt_style a{
      font-size: 20px;
      color: red;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">

    <?php echo $__env->make('partials.backend_top_nav_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo $__env->make('partials.backend_aside_teamlead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          Application Review / Assignment
          <small>Team Lead Control panel</small>
        </h1>
      </section>


      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-md-4">
            <div class="box box-primary">
              <div class="box-body box-profile">

                <h3 class="profile-username text-center" style="text-transform: capitalize;"><?php echo e($applicationReview->name_of_gas_plant); ?></h3>

                <p class="text-muted text-center"><?php echo e($applicationReview->application_id); ?></p>

                <ul class="list-group list-group-unbordered">
                  <li class="list-group-item">
                    <b>Application type</b> <a class="pull-right"><?php echo e($applicationReview->application_type); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Sub-category</b> <a class="pull-right"><?php echo e($applicationReview->sub_category); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Plant type</b> <a class="pull-right"><?php echo e($applicationReview->plant_type); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Capacity of tank</b> <a class="pull-right"><?php echo e($applicationReview->capacity_of_tank); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>State</b> <a class="pull-right"><?php echo e($applicationReview->state); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>L.G.A</b> <a class="pull-right"><?php echo e($applicationReview->lga); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Town</b> <a class="pull-right"><?php echo e($applicationReview->town); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Address</b> <a class="pull-right"><?php echo e($applicationReview->address); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Application Date</b> <a class="pull-right"><?php echo e($applicationReview->created_at->diffForHumans()); ?></a>
                  </li>
                  <?php if($applicationStatus != null): ?>
                    <li class="list-group-item">
                      <b>Application Status</b>
                      <?php if($reportDocument != null): ?>
                        <div class="box-tools pull-right tools" data-toggle="modal" data-target="#report" style="position: relative; bottom: 5px;">
                          <button type="button" class="btn btn-box-tool"><i class="fa fa-eye" style="font-size: 18px;"></i></button>
                        </div>
                      <?php endif; ?>
                      <a class="pull-right text-red"><?php echo e($applicationStatus->job_application_status); ?></a>
                    </li>
                    <li class="list-group-item">
                      <b>Staff Assigned <i class="fa fa-check-circle text-green"></i></b> <a class="pull-right text-green"><?php echo e($applicationStatus->staff_id); ?></a>
                    </li>
                    <?php if($applicationStatus->job_application_status == "Report Submitted"): ?>
                      <?php if($applicationReview->sub_category == 'Site Suitability Inspection'): ?>
                        <form role="form" method="post" action="/tlApproves">
                          <?php echo e(csrf_field()); ?>

                          <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->application_id); ?>">
                          <input type="text" hidden name="sub_category" value="<?php echo e($applicationReview->sub_category); ?>">
                          <input type="text" hidden name="marketer_id" value="<?php echo e($applicationReview->marketer_id); ?>">
                          <input type="text" hidden name="company_id" value="<?php echo e($reportDocument->company_id); ?>">
                          <input type="text" hidden name="staff_id" value="<?php echo e($reportDocument->staff_id); ?>">
                          <input type="text" hidden name="report_url" value="<?php echo e($reportDocument->report_url); ?>">
                          <div class="box-footer">
                            <input type="submit" name="decline" value="Decline" class="pull btn btn-danger">
                            <input type="submit" name="approve" value="Approve" class="pull-right btn btn-success">
                          </div>
                        </form>
                      <?php elseif($applicationStatus->to_head_gas != "true"): ?>
                        <form role="form" method="post" action="/up_to_headgas">
                          <?php echo e(csrf_field()); ?>

                          <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->application_id); ?>">
                          <div class="box-footer">
                            <input type="text" hidden name="staff_id" value="<?php echo e($reportDocument->staff_id); ?>">
                            <input type="submit" name="sendToHeadGas" value="Send to Head Gas" class="pull-left btn btn-success">
                            <input type="submit" name="sendToStaff" value="Send to Staff" class="pull-right btn btn-danger">
                          </div>
                        </form>
                      <?php endif; ?>
                    <?php endif; ?>

                  <?php endif; ?>
                </ul>
                <div class="modal fade" id="report" style="display: none;">
                  <div class="modal-dialog" style="width: 1400px;">
                    <div class="modal-content" style="background: transparent;">
                      <?php if($reportDocument != null): ?>
                        <img src="/storage/comp_reports/<?php echo e($reportDocument->company_id); ?>/<?php echo e($reportDocument->staff_id); ?>/<?php echo e($reportDocument->application_id); ?>/<?php echo e($reportDocument->report_url); ?>" alt="">
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </div>

              <!-- /.box-body -->
            </div>
            <div class="box box-primary direct-chat direct-chat-warning">
              <div class="box-header with-border">
                <h3 class="box-title">Report Comments</h3>
                <div class="box-tools pull-right">
                  <span data-toggle="tooltip" title="" class="badge bg-blue" data-original-title="<?php echo e($applicationComments->count()); ?> Comments"><?php echo e($applicationComments->count()); ?></span>
                  <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                </div>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                <!-- Conversations are loaded here -->
                <div class="direct-chat-messages">
                  <!-- Message. Default to the left -->
                  <?php $__currentLoopData = $applicationComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                      <div class="direct-chat-msg">
                        <div class="direct-chat-info clearfix">
                          <span class="direct-chat-name pull-left" style="text-transform: capitalize;"><?php echo e($comment->staff['first_name']); ?> <?php echo e($comment->staff['last_name']); ?> <i class="text-yellow"><b>(<?php echo e($comment->staff['role']); ?>)</b></i></span>
                          <span class="direct-chat-timestamp pull-right"><?php echo e($comment->created_at->diffForHumans()); ?></span>
                        </div>
                        <!-- /.direct-chat-info -->
                        <img class="direct-chat-img" src="/dist/img/user1-128x128.jpg" alt="message user image">
                        <!-- /.direct-chat-img -->
                        <div class="direct-chat-text">
                          <?php echo e($comment->comment); ?>

                        </div>
                        <!-- /.direct-chat-text -->
                      </div>
                      <!-- /.direct-chat-msg -->
                      <br>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <form action="/make_report_comment" method="post">
                  <?php echo e(csrf_field()); ?>

                  <div class="input-group">
                    <input type="text" name="comment" placeholder="Type Message ..." class="form-control" required>
                    <input type="text" name="application_id" hidden value="<?php echo e($applicationReview->application_id); ?>">
                    <span class="input-group-btn">
                      <button type="submit" class="btn btn-primary btn-flat">Make Comment</button>
                    </span>
                  </div>
                </form>
              </div>
              <!-- /.box-footer-->
            </div>

          </div>
          <div class="col-md-8">
            <?php if(optional($applicationStatus)->job_application_status != "Started"): ?>
              <?php if(optional($applicationStatus)->job_application_status != "Report Submitted"): ?>
                <?php if(optional($applicationStatus)->job_application_status != "Site Suitable"): ?>
                  <?php if(optional($applicationStatus)->job_application_status != "Pending Approval"): ?>
                    <div class="box">
                      <div class="box-header with-border">
                        <h3 class="box-title">Select Staff To Assign</h3>
                      </div>
                      <!-- /.box-header -->
                      <div class="box-body">
                        <table id="example1" class="table table-bordered table-hover">
                          <thead>
                            <tr>
                              <th>Staff ID</th>
                              <th>Firstname</th>
                              <th>Lastname</th>
                              <th>Email Address</th>
                              <th>Mobile Number</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td class="sorting_1"><a class="label label-success" style="font-size: 14px;"><?php echo e($staff->staff_id); ?></a></td>
                                <td><?php echo e($staff->first_name); ?></td>
                                <td><?php echo e($staff->last_name); ?></td>
                                <td><?php echo e($staff->email_address); ?></td>
                                <td><?php echo e($staff->mobile_number); ?></td>
                                <td>
                                  <form action="/tlDocument_assign" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->application_id); ?>">
                                    <input type="text" hidden name="application_type" value="<?php echo e($applicationReview->application_type); ?>">
                                    <input type="text" hidden name="sub_category" value="<?php echo e($applicationReview->sub_category); ?>">
                                    <input type="text" hidden name="id" value="<?php echo e($applicationReview->id); ?>">
                                    <input type="text" hidden name="staff_id" value="<?php echo e($staff->staff_id); ?>">
                                    <?php if(optional($applicationStatus)->job_application_status == "Assigned"): ?>
                                      <input type="submit" class="btn btn-danger" value="Re-Assign" style="padding: 2px 25px;">
                                    <?php else: ?>
                                      <input type="submit" class="btn btn-primary" value="Assign" style="padding: 2px 25px;">
                                    <?php endif; ?>

                                  </form>
                                  
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                      </div>
                      <!-- /.box-body -->
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
              <?php endif; ?>
            <?php endif; ?>

          </div>
          <div class="col-md-8">
            <div class="box box-primary">
              <!-- /.box-header -->
              <div class="box-body">
                <?php if($applicationReview->sub_category == 'Site Suitability Inspection' || $applicationReview->sub_category == 'ATC'): ?>
                  <?php echo $__env->make('partials.m_view_application_docs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($applicationReview->sub_category == 'LTO'): ?>
                  <?php echo $__env->make('partials.m_view_application_docs_lto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($applicationReview->sub_category == 'Renewal'): ?>
                  <?php echo $__env->make('partials.m_view_application_docs_lto_renewal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($applicationReview->sub_category == 'Take Over'): ?>
                  <?php echo $__env->make('partials.m_view_application_docs_takeover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($applicationReview->sub_category == 'Pressure Testing'): ?>
                  <?php echo $__env->make('partials.m_view_application_docs_pressure_test', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
              </div>
              <!-- /.box-body -->
            </div>
          </div>


        </div>

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('partials.base_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
  <!-- page script -->
  <script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>