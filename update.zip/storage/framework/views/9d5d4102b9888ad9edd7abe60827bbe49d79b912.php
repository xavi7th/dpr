<?php $__env->startSection('title'); ?>
  DPR ZOPSCON | Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagestyles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">

    <?php echo $__env->make('partials.backend_top_nav_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo $__env->make('partials.backend_aside_zopscon', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content-header">
        <h1>
          Inbox
          <small>ZOPSCON Control panel</small>
        </h1>
      </section>

      <section class="content">
        <div class="row">
          <?php echo $__env->make('partials.zopscon_folders', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /.col -->
            
            <div class="col-md-9">
              <div class="box box-success">
                <div class="box-header with-border">
                  <h3 class="box-title">Inbox</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>Name of Company</th>
                        <th>Application Type</th>
                        <th>Sub-Category</th>
                        <th>Date Received</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $inbox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <?php if($item->read == 'true'): ?>
                            <td><i class="fa fa-circle" style="padding-right: 15px; color: #4CAF50;"></i><a href="/zopscon_document_review/<?php echo e($item->application_id); ?>" class="" style="font-size: 16px; text-transform: capitalize; font-weight: 500;"><?php echo e($item->app_doc_review['name_of_gas_plant']); ?></a></td>
                          <?php else: ?>
                            <td><i class="fa fa-circle" style="padding-right: 15px; color: #F44336;"></i><a href="/zopscon_document_review/<?php echo e($item->application_id); ?>" class="" style="font-size: 16px; text-transform: capitalize; font-weight: 500;"><?php echo e($item->app_doc_review['name_of_gas_plant']); ?></a></td>
                          <?php endif; ?>
                          <td><?php echo e($item->application_type); ?></td>
                          <td><?php echo e($item->sub_category); ?></td>
                          <td><?php echo e(Carbon\Carbon::parse($item->created_at)->toDayDateTimeString()); ?></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.box-body -->
              </div>
              

            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </section>
      </div>
      <?php echo $__env->make('partials.base_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('pagescript'); ?>
    <script>
    $.widget.bridge('uibutton', $.ui.button);
  </script>
  <script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<script>
$(function () {
  //Enable iCheck plugin for checkboxes
  //iCheck for checkbox and radio inputs
  $('.mailbox-messages input[type="checkbox"]').iCheck({
    checkboxClass: 'icheckbox_flat-blue',
    radioClass: 'iradio_flat-blue'
  });

  //Enable check and uncheck all functionality
  $(".checkbox-toggle").click(function () {
    var clicks = $(this).data('clicks');
    if (clicks) {
      //Uncheck all checkboxes
      $(".mailbox-messages input[type='checkbox']").iCheck("uncheck");
      $(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');
    } else {
      //Check all checkboxes
      $(".mailbox-messages input[type='checkbox']").iCheck("check");
      $(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');
    }
    $(this).data("clicks", !clicks);
  });

  //Handle starring for glyphicon and font awesome
  $(".mailbox-star").click(function (e) {
    e.preventDefault();
    //detect type
    var $this = $(this).find("a > i");
    var glyph = $this.hasClass("glyphicon");
    var fa = $this.hasClass("fa");

    //Switch states
    if (glyph) {
      $this.toggleClass("glyphicon-star");
      $this.toggleClass("glyphicon-star-empty");
    }

    if (fa) {
      $this.toggleClass("fa-star");
      $this.toggleClass("fa-star-o");
    }
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>