<?php $__env->startSection('title'); ?>
  DPR Marketer | View Application Documents
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagestyles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">

    <?php echo $__env->make('partials.backend_top_nav_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo $__env->make('partials.backend_aside_marketer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          Application Documents
          <small>Marketer Control panel</small>
        </h1>
      </section>


      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-md-4">
            <div class="box box-primary">
              <div class="box-body box-profile">

                <h3 class="profile-username text-center"><?php echo e($applicationReview->name_of_gas_plant); ?></h3>

                <p class="text-muted text-center"><?php echo e($applicationReview->application_id); ?></p>

                <ul class="list-group list-group-unbordered">
                  <li class="list-group-item">
                    <b>Application type</b> <a class="pull-right"><?php echo e($applicationReview->application_type); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Sub-category</b> <a class="pull-right"><?php echo e($applicationReview->sub_category); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Plant type</b> <a class="pull-right"><?php echo e($applicationReview->plant_type); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Capacity of tank</b> <a class="pull-right"><?php echo e($applicationReview->capacity_of_tank); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>State</b> <a class="pull-right"><?php echo e($applicationReview->state); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>L.G.A</b> <a class="pull-right"><?php echo e($applicationReview->lga); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Town</b> <a class="pull-right"><?php echo e($applicationReview->town); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Address</b> <a class="pull-right"><?php echo e($applicationReview->address); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Date</b> <a class="pull-right"><?php echo e(Carbon\Carbon::parse($applicationReview->created_at)->toFormattedDateString()); ?></a>
                  </li>
                  <?php if($applicationReview->application_status): ?>
                    <li class="list-group-item">
                      <b>Status</b> <a class="pull-right"><?php echo e($applicationReview->application_status); ?></a>
                      <?php if($applicationReview->application_status == 'Site Suitable' || $applicationReview->application_status == 'ATC Issued'): ?>
                        <i class="fa fa-check text-green"></i>
                      <?php elseif($applicationReview->application_status == 'Site NOT Suitable' || $applicationReview->application_status == 'ATC Not Issued'): ?>
                        <i class="fa fa-close text-red"></i>
                      <?php endif; ?>
                    </li>
                  <?php endif; ?>
                  <?php if(optional($licenseRenewalDetail)->application_status == 'Application Pending'): ?>
                    <li class="list-group-item">
                      <b>Renewal Status</b> <a class="pull-right"><?php echo e($licenseRenewalDetail->application_status); ?></a>
                      <i class="fa fa-close text-red"></i>
                    </li>
                  <?php endif; ?>
                  <br>
                  <?php if($applicationReview->application_status == 'Not Submitted'): ?>
                    <form class="" action="/mSubmitApplication" method="post">
                      <?php echo e(csrf_field()); ?>

                      <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->id); ?>">
                      <input type="text" hidden name="application_type" value="<?php echo e($applicationReview->application_type); ?>">
                      <input type="text" hidden name="sub_category" value="<?php echo e($applicationReview->sub_category); ?>">
                      <button type="submit" class="btn btn-primary btn-block">Submit Application</button>
                    </form>
                  <?php else: ?>
                    <?php if($applicationReview->application_status == 'Site Suitable'): ?>
                      <form class="" action="/apply_for_atc" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->application_id); ?>">
                        <button type="submit" class="btn btn-primary btn-block">Apply For ATC</button>
                      </form>
                    <?php endif; ?>
                    <?php if($applicationReview->sub_category == 'ATC' && $applicationReview->application_status != 'LTO Issued'): ?>
                      <form class="" action="/apply_for_lto" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->application_id); ?>">
                        <button type="submit" class="btn btn-primary btn-block">Apply For LTO</button>
                      </form>
                    <?php endif; ?>
                  <?php endif; ?>

                </ul>
              </div>
              <!-- /.box-body -->
            </div>
            <?php if($licenseDetail != null): ?>
              <?php if(now()->gte($licenseDetail->expiry_date) || now()->addMonths(3)->gte($licenseDetail->expiry_date)): ?>
                <div class="box box-info">
                  <div class="box-header with-border">
                    <h3 class="box-title">License Renewal</h3>
                    <?php if($applicationReview->sub_category == "ATC"): ?>
                      <div class="tools pull-right" data-toggle="modal" data-target="#reason" style="cursor: pointer;">
                        <i class="fa fa-edit text-red"></i>
                      </div>
                    <?php endif; ?>
                  </div>
                  <!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="POST" action="/apply_for_lto_renewal" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                      <div class="form-group">
                        <label style="text-transform: uppercase;">Copy of Last Expired License</label>
                        <input type="file" name="COLEL_doc">
                      </div>
                      <hr>
                      <div class="form-group">
                        <label style="text-transform: uppercase;">Payment Receipt</label>
                        <input type="file" name="PR_doc">
                      </div>
                      <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->application_id); ?>">
                      <input type="text" hidden name="marketer_id" value="<?php echo e($applicationReview->marketer_id); ?>">
                      
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                      <button type="submit" class="btn btn-primary pull-right">Apply For License Renewal</button>
                    </div>
                    <!-- /.box-footer -->
                  </form>
                </div>
              <?php endif; ?>
            <?php endif; ?>

          </div>
          <div class="col-md-8">
            <div class="box box-primary">
              <div class="box-header ui-sortable-handle" style="cursor: move;">
                <h3 class="box-title">Application ID: <?php echo e($applicationID->application_id); ?></h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
              <?php if($applicationReview->sub_category == 'Site Suitability Inspection' || $applicationReview->sub_category == 'ATC'): ?>
                <?php echo $__env->make('partials.m_view_application_docs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php elseif($applicationReview->sub_category == 'LTO'): ?>
                <?php echo $__env->make('partials.m_view_application_docs_lto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php elseif($applicationReview->sub_category == 'Renewal'): ?>
                <?php echo $__env->make('partials.m_view_application_docs_lto_renewal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php elseif($applicationReview->sub_category == 'Take Over'): ?>
                <?php echo $__env->make('partials.m_view_application_docs_takeover', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php elseif($applicationReview->sub_category == 'Pressure Testing'): ?>
                
              <?php endif; ?>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php echo $__env->make('partials.base_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>