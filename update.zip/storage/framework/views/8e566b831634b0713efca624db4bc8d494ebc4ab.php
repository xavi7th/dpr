<div class="box">
  <div class="box-header with-border">
    <h3 class="box-title">Select Staff To Assign</h3>
  </div>
  <!-- /.box-header -->
  <div class="box-body">
    <table id="example1" class="table table-bordered table-hover">
      <thead>
        <tr>
          <th>Staff ID</th>
          <th>Firstname</th>
          <th>Lastname</th>
          <th>Email Address</th>
          <th>Mobile Number</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="sorting_1"><a class="label label-success" style="font-size: 14px;"><?php echo e($staff->staff_id); ?></a></td>
            <td><?php echo e($staff->first_name); ?></td>
            <td><?php echo e($staff->last_name); ?></td>
            <td><?php echo e($staff->email_address); ?></td>
            <td><?php echo e($staff->mobile_number); ?></td>
            <td>
              <form action="/tlDocument_assign" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="text" hidden name="application_id" value="<?php echo e($applicationReview->application_id); ?>">
                <input type="text" hidden name="staff_id" value="<?php echo e($staff->staff_id); ?>">
                <?php if(optional($applicationStatus)->job_application_status == "Assigned"): ?>
                  <input type="submit" class="btn btn-danger" value="Re-Assign" style="padding: 2px 25px;">
                <?php else: ?>
                  <input type="submit" class="btn btn-primary" value="Assign" style="padding: 2px 25px;">
                <?php endif; ?>

              </form>
              
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
  <!-- /.box-body -->
</div>
