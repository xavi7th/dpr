<?php $__env->startSection('title'); ?>
  DPR Head Gas | Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagestyles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">

    <?php echo $__env->make('partials.backend_top_nav_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo $__env->make('partials.backend_aside_headgas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          Dashboard
          <small>Head Gas Control panel</small>
        </h1>
      </section>

      <!-- Main content -->
      
      <section class="content">

        <div class="row">
          <?php echo $__env->make('partials.headgas_folders', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <!-- ./col -->
          <div class="col-md-9">
            <div class="box box-success">
              <div class="box-header with-border">
                <h3 class="box-title">Inbox</h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                <table id="example1" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th>Name of Company</th>
                      <th>Application Type</th>
                      <th>Sub-Category</th>
                      <th>Date Received</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $inbox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <?php if($item->read == 'true'): ?>
                          <td><i class="fa fa-circle" style="padding-right: 15px; color: #4CAF50;"></i><a href="/headgas_document_review/<?php echo e($item->application_id); ?>" class="" style="font-size: 16px; text-transform: capitalize; font-weight: 500;"><?php echo e($item->app_doc_review['name_of_gas_plant']); ?></a></td>
                        <?php else: ?>
                          <td><i class="fa fa-circle" style="padding-right: 15px; color: #F44336;"></i><a href="/headgas_document_review/<?php echo e($item->application_id); ?>" class="" style="font-size: 16px; text-transform: capitalize; font-weight: 500;"><?php echo e($item->app_doc_review['name_of_gas_plant']); ?></a></td>
                        <?php endif; ?>
                        <td><?php echo e($item->application_type); ?></td>
                        <td><?php echo e($item->sub_category); ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($item->created_at)->toDayDateTimeString()); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.box-body -->
            </div>
            

          </div>
        </div>

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('partials.base_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>