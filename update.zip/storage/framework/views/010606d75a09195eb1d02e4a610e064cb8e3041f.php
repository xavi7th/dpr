<?php $__env->startSection('title'); ?>
  DPR Administrator | Create Company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagestyles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">

    <?php echo $__env->make('partials.backend_top_nav_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php if(Auth::user()->role == 'Marketer'): ?>
      <?php echo $__env->make('partials.backend_aside_marketer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Admin'): ?>
      <?php echo $__env->make('partials.backend_aside_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Staff'): ?>
      <?php echo $__env->make('partials.backend_aside_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Team Lead'): ?>
      <?php echo $__env->make('partials.backend_aside_teamlead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'Head Gas M&G Lagos'): ?>
      <?php echo $__env->make('partials.backend_aside_headgas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'ADO'): ?>
      <?php echo $__env->make('partials.backend_aside_ado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(Auth::user()->role == 'ZOPSCON'): ?>
      <?php echo $__env->make('partials.backend_aside_zopscon', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          Settings
          <small><?php echo e(Auth::user()->role); ?> Control Panel</small>
        </h1>
      </section>

      <!-- Main content -->
      <section class="content">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-md-4">
            <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Change Password</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->
              <form role="form" action="/change_password" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="box-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">New Password</label>
                    <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Enter Password">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password Confirmation</label>
                    <input type="password" class="form-control" name="password_confirmation" id="exampleInputPassword1" placeholder="Retype Password">
                  </div>
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                  <button type="submit" class="btn btn-primary">Change Password</button>
                </div>
              </form>
            </div>
          </div>

          <div class="col-md-4">
            <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Modify Records</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="POST" action="/update_staff_records">
              <?php echo e(csrf_field()); ?>

              <div class="box-body">
                <div class="form-group">
                  <label>Select Record to modify</label>
                  <select class="form-control select2" name="record_name" style="width: 100%;">
                    <option selected="selected" value="null">Select Record</option>
                    <option value="first_name">First Name</option>
                    <option value="last_name">Last Name</option>
                    <option value="mobile_number">Mobile Number</option>
                    <option value="email_address">Email Address</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Enter Value</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="record_value" placeholder="Enter Value">
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary pull-right">Submit</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
          </div>
        </div>


      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('partials.base_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>