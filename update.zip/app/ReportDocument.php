<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReportDocument extends Model
{
    protected $guarded = [];
}
