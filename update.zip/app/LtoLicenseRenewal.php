<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LtoLicenseRenewal extends Model
{
    protected $guarded = [];
}
