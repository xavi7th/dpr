<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AtcInspectionDocuments extends Model
{
    protected $guarded = [];
}
