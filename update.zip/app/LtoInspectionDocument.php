<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LtoInspectionDocument extends Model
{
    protected $guarded = [];
}
