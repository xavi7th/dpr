<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SiteSuitabilityReports extends Model
{
    protected $guarded = [];
}
