<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IssuedLtoLicense extends Model
{
    protected $guarded = [];
}
