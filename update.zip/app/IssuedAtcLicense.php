<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IssuedAtcLicense extends Model
{
    protected $guarded = [];
}
