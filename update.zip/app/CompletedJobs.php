<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompletedJobs extends Model
{
    protected $guarded = [];
}
