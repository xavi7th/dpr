<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SiteSuitabilityInspectionDocuments extends Model
{
    protected $guarded = [];
    
}
